module.exports = {
    adal: {
      instance: 'https://login.microsoftonline.com/',
      tenant: 'nmfntest.onmicrosoft.com',
      clientId: '6b85f2f5-8729-4558-850f-f023d18f3e78',
      extraQueryParameter: 'nux=1&domain_hint=nmcop.com',
      cacheLocation: 'localStorage',
      redirectUri: 'http://localhost:3000/home',
      expireOffsetSeconds: 300,
    }
};