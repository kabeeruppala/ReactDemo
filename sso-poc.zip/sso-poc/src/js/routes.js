import React from 'react';
import {Route,IndexRoute} from 'react-router';
import App from './components/App';
 // render={() => (<Redirect from="/" to="home"/>)}>
 //<IndexRoute component ={App}/>
 //<Route path="home" component ={App}/>
export default (
  
            
            <Route path="/" component ={App}>
          
          <Route path="home" component ={App}/>
          
         </Route>
);