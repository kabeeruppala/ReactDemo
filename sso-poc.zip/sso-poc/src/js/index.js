
import React from 'react';
import { render } from 'react-dom';
import nmAdal from './utils/nm-adal';
import routes from './routes';
import {Provider} from 'react-redux';
import {Router,browserHistory} from 'react-router';
/*.isAuthenticated().then( () => {
render(<h1> Hello </h1>, document.getElementById('root'));
});*/
nmAdal.isAuthenticated().then( () => {
    //debugger;
  render(
    //<Provider store ={store}>
        <Router history ={browserHistory} routes ={routes}/>,
    //</Provider>,
    document.getElementById('root')
);
});


