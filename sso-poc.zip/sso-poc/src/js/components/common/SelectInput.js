import React, { PropTypes } from 'react';

const SelectInput = ({name, label, onChange, defaultOption, value, error, options}) => {
  return (
    <div className="form-group">
      <label htmlFor="{name}">{label}</label>
      <div className="field">
        {/* Note, value is set here rather than on the option! */}
        <select
          name={name}
          value={value}
           className="form-control">
            <option value="">{defaultOption}</option>
            <option key="TS1" value="TS 1-Medical History-Cardiovascular Profile">TS 1-Medical History-Cardiovascular Profile</option>;
            <option key="TS2" value="TS 2 - Tobacco - Confidential Lan Needed">TS 2 - Tobacco - Confidential Lan Needed</option>;
                     
        </select>
        {error && <div className="alert alert-danger">{error}</div>}
      </div>
    </div>
  );
};

SelectInput.propTypes = {
  name: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
 // onChange: PropTypes.func.isRequired,
  defaultOption: PropTypes.string,
  value: PropTypes.string,
  error: PropTypes.string,
  options: PropTypes.arrayOf(PropTypes.object)
};

export default SelectInput;
