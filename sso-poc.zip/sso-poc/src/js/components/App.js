import React  from 'react';
import TextInput from './common/TextInput';
import SelectInput from './common/SelectInput';
export default class App extends React.Component
{
    render()
    {
        return(
            <div>
        
      <h2>FRONT END APPLICATION</h2>
      <br/>
      <form >
        </form>
        <TextInput
        name=""
        label=""
        value=""
         />
         <br/>
         <SelectInput
        name=""
        label=""
        value=""
        defaultOption="Select"
        />
        <br/>
        <a href="https://ntapth5916m00:8443/interactive/" >InspireAppSSOTest</a>
            </div>
        );
    }
}