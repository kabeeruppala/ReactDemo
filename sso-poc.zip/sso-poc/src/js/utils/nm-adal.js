/*
This will be a NM shared module at time point....
*/

/* eslint-disable */
//import config from '../../config/development';

const AuthenticationContext = require('expose?AuthenticationContext!adal-angular');

const _adal = new AuthenticationContext(config.adal);


//stupid fix...
_adal.getUser(() => {
    //do nothing because we just needed adal._user to be populated so
    //it doesn't do a hard redirect.
});

const refreshToken = function() {

    return new Promise((resolve, reject) => {
        _adal.acquireToken(_adal.config.loginResource, (error, tokenOut) => {
            if (error){
                _adal.login();
                reject(error);
            }

            resolve(tokenOut);
        });
    });


};

const getToken = function() {
    return new Promise((resolve, reject) => {
        const token = _adal.getCachedToken(_adal.config.loginResource);

        if (token) {
            return resolve(token);
        }

        refreshToken()
            .then(token => resolve(token))
            .catch(error => reject(error));
    });
};


const isAuthenticated = function() {
  return getToken().then(token => true);
};


const tokenRefreshInterval = setInterval(getToken, 60000);


module.exports = {
    isAuthenticated: isAuthenticated,
    getToken: getToken
};
