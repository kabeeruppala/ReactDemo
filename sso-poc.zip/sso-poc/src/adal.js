//import config from '../config/dev';

const AuthenticationContext = require('expose?AuthenticationContext!adal-angular');

/*
window.Logging = {
    level: 3,
    log: console.log
 };
*/
const _adal = new AuthenticationContext(config.adal);
 _adal.handleWindowCallback();