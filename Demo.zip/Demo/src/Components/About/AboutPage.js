import React from 'react';

class AboutPage extends React.Component
{
    render() 
    {
        return(
<div>
    <h1>About</h1>
    <p>This application uses React, Redux, React Router and variety of other helpful libraries.</p>
</div>
        );
          
    }
}
export default AboutPage;